-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 15, 2019 at 10:10 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `draije1a_db_thijs`
--

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_coord`
--

CREATE TABLE `marktplaats_coord` (
  `id` int(11) NOT NULL,
  `plaats` text NOT NULL,
  `longitude` decimal(10,5) NOT NULL,
  `latitude` decimal(10,5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_data`
--

CREATE TABLE `marktplaats_data` (
  `id` int(4) NOT NULL,
  `active` set('0','1') NOT NULL,
  `marktplaats_id` int(9) NOT NULL DEFAULT '0',
  `URL` text NOT NULL,
  `title` text NOT NULL,
  `beschrijving` text NOT NULL,
  `verkoper` text NOT NULL,
  `datum` int(10) NOT NULL DEFAULT '0',
  `picture` text NOT NULL,
  `price` text NOT NULL,
  `plaats` text NOT NULL,
  `distance` int(3) NOT NULL DEFAULT '0',
  `status` text NOT NULL,
  `transport` text NOT NULL,
  `term` int(3) NOT NULL DEFAULT '0',
  `time_add` int(11) NOT NULL DEFAULT '0',
  `time_change` int(11) NOT NULL DEFAULT '0',
  `title_oorspronkelijk` text NOT NULL,
  `price_oorspronkelijk` text NOT NULL,
  `times_not_seen` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_groep`
--

CREATE TABLE `marktplaats_groep` (
  `id` int(4) NOT NULL,
  `groep` text NOT NULL,
  `naam` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_lichting`
--

CREATE TABLE `marktplaats_lichting` (
  `term` int(3) NOT NULL DEFAULT '0',
  `dag` int(11) NOT NULL,
  `uur` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_log`
--

CREATE TABLE `marktplaats_log` (
  `id` int(6) NOT NULL,
  `tijd` int(10) NOT NULL DEFAULT '0',
  `ip` text NOT NULL,
  `term` int(3) NOT NULL DEFAULT '0',
  `marktplaats_id` int(9) NOT NULL DEFAULT '0',
  `log` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_notepad`
--

CREATE TABLE `marktplaats_notepad` (
  `id` int(4) NOT NULL,
  `user` int(2) NOT NULL DEFAULT '0',
  `term` int(3) NOT NULL DEFAULT '0',
  `marktplaats_id` int(9) NOT NULL DEFAULT '0',
  `tijd` int(10) NOT NULL DEFAULT '0',
  `bericht` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_subgroep`
--

CREATE TABLE `marktplaats_subgroep` (
  `id` int(4) NOT NULL,
  `groep` text NOT NULL,
  `subgroep` text NOT NULL,
  `naam` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_users`
--

CREATE TABLE `marktplaats_users` (
  `id` int(4) NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '1',
  `naam` text NOT NULL,
  `wachtwoord` text NOT NULL,
  `mail` text NOT NULL,
  `html` set('1','0') NOT NULL DEFAULT '1',
  `rss` tinyint(1) NOT NULL DEFAULT '0',
  `postcode` int(4) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marktplaats_zoeken`
--

CREATE TABLE `marktplaats_zoeken` (
  `id` int(4) NOT NULL,
  `user` int(2) NOT NULL DEFAULT '1',
  `active` set('1','0') NOT NULL DEFAULT '0',
  `sleutel` text NOT NULL,
  `logische_naam` text NOT NULL,
  `url` text NOT NULL,
  `CC_mail` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `marktplaats_coord`
--
ALTER TABLE `marktplaats_coord`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `marktplaats_data`
--
ALTER TABLE `marktplaats_data`
  ADD KEY `id` (`id`);

--
-- Indexes for table `marktplaats_groep`
--
ALTER TABLE `marktplaats_groep`
  ADD KEY `id` (`id`);

--
-- Indexes for table `marktplaats_log`
--
ALTER TABLE `marktplaats_log`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `marktplaats_notepad`
--
ALTER TABLE `marktplaats_notepad`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marktplaats_subgroep`
--
ALTER TABLE `marktplaats_subgroep`
  ADD KEY `id` (`id`);

--
-- Indexes for table `marktplaats_users`
--
ALTER TABLE `marktplaats_users`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `marktplaats_zoeken`
--
ALTER TABLE `marktplaats_zoeken`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `marktplaats_coord`
--
ALTER TABLE `marktplaats_coord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_data`
--
ALTER TABLE `marktplaats_data`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_groep`
--
ALTER TABLE `marktplaats_groep`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_log`
--
ALTER TABLE `marktplaats_log`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_notepad`
--
ALTER TABLE `marktplaats_notepad`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_subgroep`
--
ALTER TABLE `marktplaats_subgroep`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_users`
--
ALTER TABLE `marktplaats_users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marktplaats_zoeken`
--
ALTER TABLE `marktplaats_zoeken`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
